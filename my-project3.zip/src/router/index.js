import Vue from 'vue'
import Router from 'vue-router'
// import Hello from '@/components/Hello'

const Hello = resolve => {
  // require.ensure 是 Webpack 的特殊语法，用来设置 code-split point
  // （代码分块）
  require.ensure(['@/components/Hello'], () => {
    resolve(require('@/components/Hello'))
  })
}
const test = resolve => {
  // require.ensure 是 Webpack 的特殊语法，用来设置 code-split point
  // （代码分块）
  require.ensure(['@/components/test'], () => {
    resolve(require('@/components/test'))
  })
}

Vue.use(Router)

export default new Router({
  routes: [
    {
      path: '/',
      name: 'Hello',
      component: Hello
    },
    {
      path: '/test',
      name: 'test',
      component: test
    }
  ]
})
