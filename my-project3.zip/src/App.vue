<template>
  <div id="app">
    <!--头部-->
    <commonHeader></commonHeader>
    <router-view></router-view>
  </div>
</template>

<script>
import commonHeader from './components/header.vue'
import './css/common.css'
export default {
  components: {
    commonHeader
  }
}
</script>

<style>
#app {
  font-family: 'Avenir', Helvetica, Arial, sans-serif;
  -webkit-font-smoothing: antialiased;
  -moz-osx-font-smoothing: grayscale;
  text-align: center;
  color: #2c3e50;
  margin-top: 60px;
}
</style>
