<template>
	<div class="header">
		这是公用的头部
	</div>
</template>