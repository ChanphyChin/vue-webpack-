const common = {
	alertStr:function(){
		alert('this str from common.js')
	}
}
export default common