export const test = state =>{
	return state.user_name
}